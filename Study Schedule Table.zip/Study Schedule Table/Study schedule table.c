<!DOCTYPE html>
<html lang="en">
<head>
          <title></title>
</head>
<body>
    <table border="1px" width="80%" cellspacing="0px" cellpadding="10px" align="center">
        <h1 ><center>STUDY SCHEDULE</center></h1>
       
        <thead>
            <tr>
                <th style="border: 1px solid;">Time</th>
                <th style="border: 1px solid;">Monday</th>
                <th style="border: 1px solid;">Tuesday</th>
                <th style="border: 1px solid;">Wednesday</th>
                <th style="border: 1px solid;">Thursday</th>
                <th style="border: 1px solid;"></th>
                <th style="border: 1px solid;">Saturday</th>
                   
            </tr>
        </thead>
        <tbody>
            <tr>
              <td style="border: 1px solid;"><center>6:00 AM</center></td>
              <td style="border: 1px solid;"><center>Getting Ready for School</center></td>
              <td style="border: 1px solid;"><center>Getting Ready for School</center></td>
              <td style="border: 1px solid;"><center>Getting Ready for School</center></td>
              <td style="border: 1px solid;"><center>Getting Ready for School</center></td>
              <td style="border: 1px solid;"><center>Getting Ready for School</center></td>
              <td style="border: 1px solid;"><center>Sleep</center></td>
             
              
            </tr>
            <tr>
                <td style="border: 1px solid;"><center>7:00 AM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                
              
              
                
              </tr>
              <tr>
                <td style="border: 1px solid;"><center>8:00 AM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
              
                
              </tr>
              <tr>
                <td style="border: 1px solid;"><center>9:00 AM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
              
                
              </tr>
              <tr>
                <td style="border: 1px solid;"><center>10:00 AM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
                <td style="border: 1px solid;"><center>Sleep</center></td>
              
                
              </tr>
              <tr>
                <td style="border: 1px solid;"><center>11:00 AM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
              
                <td style="border: 1px solid;"><center>Eat Breakfast</center></td>
                
              </tr>
              <tr>
                <td style="border: 1px solid;"><center>12:00 PM</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
                <td style="border: 1px solid;"><center>School</center></td>
              
                <td style="border: 1px solid;"><center>Watch Tv</center></td>

                <tr>
                    <td style="border: 1px solid;"><center>01:00 PM</center></td>
                    <td style="border: 1px solid;"><center>School</center></td>
                    <td style="border: 1px solid;"><center>School</center></td>
                    <td style="border: 1px solid;"><center>School</center></td>
                    <td style="border: 1px solid;"><center>School</center></td>
                    <td style="border: 1px solid;"><center>School</center></td>
                  
                    <td style="border: 1px solid;"><center>Socialize</center></td>
                    <tr>
                        <td style="border: 1px solid;"><center>02:00 PM</center></td>
                        <td style="border: 1px solid;"><center>School</center></td>
                        <td style="border: 1px solid;"><center>School</center></td>
                        <td style="border: 1px solid;"><center>School</center></td>
                        <td style="border: 1px solid;"><center>School</center></td>
                        <td style="border: 1px solid;"><center>School</center></td>
                      
                        <td style="border: 1px solid;"><center>Study</center></td>
                        <tr>
                            <td style="border: 1px solid;"><center>03:00 PM</center></td>
                            <td style="border: 1px solid;"><center>Study/Homework</center></td>
                            <td style="border: 1px solid;"><center>Free Time</center></td>
                            <td style="border: 1px solid;"><center>Study</center></td>
                            <td style="border: 1px solid;"><center>Study</center></td>
                            <td style="border: 1px solid;"><center>Study</center></td>
                          
                            <td style="border: 1px solid;"><center>Study</center></td>

                            <tr>
                                <td style="border: 1px solid;"><center>04:00 PM</center></td>
                                <td style="border: 1px solid;"><center>Homework</center></td>
                                <td style="border: 1px solid;"><center>Study</center></td>
                                <td style="border: 1px solid;"><center>Homework</center></td>
                                <td style="border: 1px solid;"><center>Study</center></td>
                                <td style="border: 1px solid;"><center>Homework</center></td>
                              
                                <td style="border: 1px solid;"><center>Socialize</center></td>
                                <tr>
                                    <td style="border: 1px solid;"><center>05:00 PM</center></td>
                                    <td style="border: 1px solid;"><center>Homework</center></td>
                                    <td style="border: 1px solid;"><center>Study</center></td>
                                    <td style="border: 1px solid;"><center>Homework</center></td>
                                    <td style="border: 1px solid;"><center>FreeTime</center></td>
                                    <td style="border: 1px solid;"><center>Homework</center></td>
                                  
                                    <td style="border: 1px solid;"><center>Socialize</center></td>
                                    <tr>
                                        <td style="border: 1px solid;"><center>06:00 PM</center></td>
                                        <td style="border: 1px solid;"><center>Eat</center></td>
                                        <td style="border: 1px solid;"><center>Eat</center></td>
                                        <td style="border: 1px solid;"><center>Eat</center></td>
                                        <td style="border: 1px solid;"><center>Eat</center></td>
                                        <td style="border: 1px solid;"><center>Eat</center></td>
                                      
                                       <td style="border: 1px solid;"><center>Eat</center></td> 
                                    </tr>
                                    <tr>
                                        <td style="border: 1px solid;"><center>07:00 PM</center></td>
                                        <td style="border: 1px solid;"><center>Study</center></td>
                                        <td style="border: 1px solid;"><center>BibleStudy</center></td>
                                        <td style="border: 1px solid;"><center>Practice</center></td>
                                        <td style="border: 1px solid;"><center>Study</center></td>
                                        <td style="border: 1px solid;"><center>Study</center></td>
                                      
                                       <td style="border: 1px solid;"><center>Study</center></td> 
                                    </tr>
                                    <tr>
                                        <td style="border: 1px solid;"><center>08:00 PM</center></td>
                                        <td style="border: 1px solid;"><center>Homework & Study</center></td>
                                        <td style="border: 1px solid;"><center>BibleStudy</center></td>
                                        <td style="border: 1px solid;"><center>Practice</center></td>
                                        <td style="border: 1px solid;"><center>Homework & Study</center></td>
                                        <td style="border: 1px solid;"><center>Socialize</center></td>
                                      
                                       <td style="border: 1px solid;"><center>Study</center></td> 
                                    </tr>
                                    <tr>
                                        <td style="border: 1px solid;"><center>09:00 PM</center></td>
                                        <td style="border: 1px solid;"><center>Finish Homework</center></td>
                                        <td style="border: 1px solid;"><center>Homework & Study</center></td>
                                        <td style="border: 1px solid;"><center>Finish Homework</center></td>
                                        <td style="border: 1px solid;"><center>Finish Homework</center></td>
                                        <td style="border: 1px solid;"><center>Finish Homework</center></td>
                                      
                                       <td style="border: 1px solid;"><center>Watch TV</center></td> 
                                    </tr>
                                               
                                    <tr>
                                        <td style="border: 1px solid;"><center>10:00 PM</center></td>
                                        <td style="border: 1px solid;"><center>Sleep</center></td>
                                        <td style="border: 1px solid;"><center>Homework & Study</center></td>
                                        <td style="border: 1px solid;"><center>Sleep</center></td>
                                        <td style="border: 1px solid;"><center>Sleep</center></td>
                                        <td style="border: 1px solid;"><center>Sleep</center></td>
                                      
                                       <td style="border: 1px solid;"><center>Sleep</center></td> 
                                    </tr>                                                         
                                                 
                                    

                   
        </tbody>
    </table>


</body>
</html>